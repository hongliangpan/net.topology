HT for Web

目录文件结构：

/lib 产品类库目录：

    /core 核心类库目录
        ht.js 核心产品包，包含数据模型、通用组件、2D拓扑和3D引擎

    /plugin 扩展类库目录
        ht-dialog.js和ht-dialog.css 对话框扩展包，提供可弹出和关闭的对话框组件 
        ht-palette.js和ht-palette.css 组件面板扩展包，提供可折叠的分类管理组件 
        ht-contextmenu.js和ht-contextmenu.css 右键菜单扩展包，提供多级右键菜单组件           
        ht-menu.js和ht-menu.css 菜单扩展包，提供工具栏下拉菜单组件                    
        ht-rulerframe.js 刻度尺扩展包，提供适配2D拓扑，以及通用组件的刻度尺组件         
        ht-xeditinteractor.js 编辑交互扩展包，增强拓扑图的编辑交互功能
        ht-flow.js 流动扩展包，提供连线和多边形的流动动画效果        
        ht-htmlnode.js HtmlNode扩展包，增加普通html元素在2D拓扑上的呈现功能
        ht-live.js 交互式图元扩展包，在2D拓扑的基础上增加按钮、进度条，组合框等可交互式图元
        ht-telecom.js 电信扩展包，包含告警模型，告警渲染和告警传播等功能
        ht-autolayout.js 自动布局扩展包，提供多种自动布局算法
        ht-forcelayout.js 弹力布局扩展包，提供2D和3D的力导向布局算法
        ht-modeling.js 建模扩展包，提供自定义3D建模函数功能

/guide 开发手册：

    /core 核心手册目录
        /beginners/ht-beginners-guide.html 入门手册
        /vector/ht-vector-guide.html 矢量手册
        /3d/ht-3d-guide.html 3D手册
        /theme/ht-theme-guide.html 风格手册
        /abbreviation/ht-abbreviation-guide.html 简写手册

    /plugin 扩展手册目录 
        /dialog/ht-dialog-guide.html 对话框手册
        /palette/ht-palette-guide.html 组件面板手册   
        /contextmenu/ht-contextmenu-guide.html 右键菜单手册
        /menu/ht-menu-guide.html 菜单手册        
        /rulerframe/ht-rulerframe-guide.html 刻度尺手册
        /xeditinteractor/ht-xeditinteractor-guide.html 编辑交互手册 
        /flow/ht-flow-guide.html 流动手册
        /htmlnode/ht-htmlnode-guide.html HtmlNode手册          
        /live/ht-live-guide.html 交互式图元手册
        /telecom/ht-telecom-guide.html 电信扩展手册
        /autolayout/ht-autolayout-guide.html 自动布局手册
        /forcelayout/ht-forcelayout-guide.html 弹力布局手册
        /modeling/ht-modeling-guide.html 建模手册
        
网站：http://www.hightopo.com/
邮箱：service@hightopo.com

